#include <iostream>
#include <stdio.h>
using namespace std;

double korenKv(double S, int times = 1) {
    double x0 = 600, x1 = 1;
    while (x0 != x1) {
        if(times%2 == 1) {
            x1 = (x0 + S/x0)/2;
        }else if(times%2 == 0) {
            x0=(x1 + S/x1)/2;
        }
        times++;
    }
    return x0;
}
int main()
{
    printf("%f\n", korenKv(125348));
}
